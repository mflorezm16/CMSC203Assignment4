package properties;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlotTestStudent {
	private Plot plotA, plotB;

	
	@BeforeEach
	void setUp() throws Exception {
		plotA = new Plot(2, 2, 6, 6);
		plotB = new Plot(3, 4, 4, 3);
	}

	@AfterEach
	void tearDown() throws Exception {
		plotA = plotB = null;
	}
	
	
	@Test
	void testGetX() {
		System.out.println(plotA.getX());
		assertEquals(plotA.getX(), 2); 
	}
	
	@Test
	void testGetY() {
		System.out.println(plotA.getY());
		assertEquals(plotA.getY(), 2); 
	}
	
	@Test
	void testGetWidth() {
		assertEquals(plotA.getWidth(), 6); 
	}
	
	@Test
	void testGetDepth() {
		assertEquals(plotA.getDepth(), 6); 
	}
	
	
	@Test
	void testOverlaps() {
		assertTrue(plotA.overlaps(plotB));
	}
	
	
	@Test
	void testSetX() {
		Plot plotC = new Plot();
		plotC.setX(0);
		assertEquals(plotC.getX(), 0); 
	}
	
	@Test
	void testSetY() {
		Plot plotD = new Plot();
		plotD.setY(3);
		assertEquals(plotD.getY(), 3); 
	}
	
	@Test
	void testSetWidth() {
		Plot plotE= new Plot();
		plotE.setWidth(4);
		assertEquals(plotE.getWidth(), 4); 
	}
	
	@Test
	void testSetDepth() {
		Plot plotF = new Plot();
		plotF.setDepth(7);
		assertEquals(plotF.getDepth(), 7); 
	}
	
	@Test
	void testToString() {
		assertEquals(plotA.toString(), "[2],[2],[6],[6]");
	}
	
	
	@Test
	void testEncompasses() {
		assertTrue(plotA.encompasses(plotB));
	}
	
	@Test
	void testPlotDefaultConstructor() {
		Plot plotH = new Plot();
		assertNotNull(plotH);
		assertEquals(plotH.getWidth(), 1);
		assertEquals(plotH.getDepth(), 1);
	}
	
	@Test
	void testConstructorWithParameters() {
		Plot plotG = new Plot(2,4,1,2);
		assertNotNull(plotG);
		assertEquals(plotG.getX(), 2);
		assertEquals(plotG.getY(), 4);
		assertEquals(plotG.getWidth(), 1);
		assertEquals(plotG.getDepth(), 2);
	}
	
	@Test
	void testOtherPlot() {
		Plot plotJ = new Plot(2,4,1,2);
		Plot plotK = new Plot(plotJ);
		assertNotNull(plotK);
		assertEquals(plotK.getX(), 2);
		assertEquals(plotK.getY(), 4);
		assertEquals(plotK.getWidth(), 1);
		assertEquals(plotK.getDepth(), 2);
	}

	
}
