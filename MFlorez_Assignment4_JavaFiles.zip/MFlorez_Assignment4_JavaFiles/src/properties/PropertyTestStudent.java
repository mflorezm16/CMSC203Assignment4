package properties;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class PropertyTestStudent {
	
	Property propertyA;
	Property propertyB;
	
	@BeforeEach
	void setUp() throws Exception{
		propertyA = new Property("Property 335", "Bethesda", 2450.00, "City Bank");
		propertyB = new Property("Property 236", "Silver Spring", 1230.00, "Bank of America", 4,7,2,2);

	}

	@AfterEach
	void tearDown() throws Exception{
		propertyA = null;
		propertyB = null;
	}
	
	@Test
	void testProperty() {
		assertEquals("Property 335", propertyA.getPropertyName());
		assertEquals("Bethesda", propertyA.getCity());
		assertEquals(2450.00, propertyA.getRentAmount());
		assertEquals("City Bank", propertyA.getOwner());
	}
	
	@Test
	void testPropertyWithPlot() {
		assertNotNull(propertyB.getPlot());
	}
	
	
	@Test
	void testGetPropertyName() {
		assertEquals("Property 335", propertyA.getPropertyName());
	}
	
	@Test
	void testGetCity() {
		assertEquals("Bethesda", propertyA.getCity());
	}
	
	@Test
	void testGetOwner() {
		assertEquals("City Bank", propertyA.getOwner());
	}
	

	@Test
	void testGetRentAmount() {
		assertEquals(2450.00, propertyA.getRentAmount());
	}
	
	@Test
	void testGetPlot() {
		assertNull(propertyA.getPlot());
	}
	
	@Test
	void testToString() {
		System.out.println(propertyA.toString());
		assertEquals(propertyA.toString(),"[Property 335],[Bethesda],[City Bank],[2450.0]");
	}

}
