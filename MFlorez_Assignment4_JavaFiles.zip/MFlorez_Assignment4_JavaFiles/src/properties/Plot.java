package properties;

public class Plot extends Object {
	
	
	private int depth;
	private int width;
	private int x;
	private int y;
	
	
	public Plot() {
		width = 1;
		depth = 1;
	}
	
	public Plot(int x, int y, int width, int depth) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}
	
	public Plot(Plot otherPlot) {
		x = otherPlot.getX();
		y = otherPlot.getY();
		width = otherPlot.getWidth();
		depth = otherPlot.getDepth();
	}
	
	
	
	public boolean encompasses(Plot plot){
		
		if(this.x > plot.getX()) {
			return false;
		}
		if(this.y > plot.getY()) {
			return false;
		}
		
		if(this.x + this.width < plot.getX() + plot.getWidth()) {
			return false;
		}
		if(this.y + this.depth < plot.getY() + plot.getDepth()) {
			return false;
		}
		
		return true;
	}
	
	public int getDepth(){
		return depth;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public boolean overlaps(Plot plot) {
		
		if(this.x + this.width <= plot.getX() || plot.getX() + plot.getWidth() < this.x) {
			return false;
		}
		if(this.y + this.depth <= plot.getY() || plot.getY() + plot.getDepth() < this.y) {
			return false;
		}
		
		return true;
	}
	
	
	public void setDepth(int depth) {
		this.depth = depth;
	}
	
	public void setWidth(int width) {
		this.width = width;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public String toString() {
		return "["+ x + "]" + "," + "[" + y + "]" + "," + "[" + width + "]" + "," + "[" + depth + "]";
	}

}
