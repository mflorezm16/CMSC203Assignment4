package properties;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class ManagementCompanyTestStudent {
	properties.Property sampleProperty;
	ManagementCompany mangementCo ; 
	
	@BeforeEach
	public void setUp() throws Exception {
		mangementCo= new ManagementCompany("Roosevelt", "999999999",5);
	}

	@AfterEach
	public void tearDown() throws Exception {
		mangementCo=null;
	}

	@Test
	public void testAddProperty() {
		ManagementCompany managementCo2 = new ManagementCompany();
		sampleProperty = new properties.Property ("Starboard", "Miller", 1877, "Eric Smith",5,2,4,0);		 
		assertEquals(managementCo2.addProperty(sampleProperty),1);	//property has been successfully added to index 0
	}
	
	@Test
	public void testGetPropertiesCount() {
		ManagementCompany managementCo2 = new ManagementCompany();
		sampleProperty = new properties.Property ("Starboard", "Miller", 1877, "Eric Smith",5,2,4,0);		 
		assertEquals(managementCo2.addProperty(sampleProperty),1);	
		assertEquals(managementCo2.getPropertiesCount(), 1);
	}

	@Test
	public void testToString() {
		sampleProperty = new properties.Property ("Starboard", "Miller", 1877.0, "Eric Smith",5,2,4,0);
		assertEquals(mangementCo.addProperty(sampleProperty), 1);	//property has been successfully added to index 0
		String expectedString = "List of the properties for Roosevelt, taxID: 999999999\n"
				+ "_________________________\n"
				+ "Starboard,Miller,Eric Smith,1877.0\n"
				+ "_________________________\n"
				
				+ "total management fee: " + 5.0 + "\n";
		System.out.println(mangementCo.toString());
		System.out.println(expectedString);
		assertEquals(expectedString, mangementCo.toString());
		
		

				
	}

}
