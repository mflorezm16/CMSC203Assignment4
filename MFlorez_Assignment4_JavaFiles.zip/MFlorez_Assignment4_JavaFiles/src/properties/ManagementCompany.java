package properties;
import java.lang.StringBuilder;
public class ManagementCompany extends Object {
	
	
	private int addProperty;
	private Property highestRentProperty;
	private String name;
	private String taxID;
	private double mgmFee;
	private Property[] properties;
	private int numberOfProperties = 0;
	public static final int MAX_PROPERTY = 5;
	public static final int MGMT_WIDTH = 10;
	public static final int MGMT_DEPTH = 10;
	private Plot plot;
	
	public ManagementCompany() {
		this.properties = new Property[MAX_PROPERTY];
	}
	
	ManagementCompany(String name, String taxID, double mgmFee){
		this.name = name;
		this.taxID = taxID;
		this.mgmFee = mgmFee;
		this.properties = new Property[MAX_PROPERTY];
		this.plot = new Plot();
	}
	
	ManagementCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth) {
		this.name = name;
		this.taxID = taxID;
		this.mgmFee = mgmFee;
		this.plot = new Plot(x, y, width, depth);
		this.properties = new Property[MAX_PROPERTY];
	}
	
	
	public int addProperty(String name, String city, double rent, String owner) {
		Property newProperty = new Property(name, city, rent, owner);
		int index = this.numberOfProperties + 1;
		if(index < MAX_PROPERTY) {
		this.properties[index] = newProperty;
		this.numberOfProperties ++;
		}
		
		// return this.properties.length;
		return numberOfProperties;
	}
	
	public int addProperty(String name, String city, double rent, String owner, 
							int x, int y, int depth, int width) {
		Property newProperty = new Property(name, city, rent, owner, x, y, depth, width);
		int index = this.numberOfProperties + 1;
		if(index < MAX_PROPERTY) {
		this.properties[index] = newProperty;
		this.numberOfProperties ++;

		}
		// this.numberOfProperties ++;
		// return this.properties.length;
		return numberOfProperties;
	}
	
	public int addProperty (Property property){
		// this.numberOfProperties ++;
		int index = this.numberOfProperties + 1;
		if(index < MAX_PROPERTY) {
		this.properties[index] = property;
		this.numberOfProperties ++;
		}
		return numberOfProperties;
		//return this.properties.length;
	}
	
	public Property getHighestRentProperty() {
		double highestRent = 0.0;
		for(int i = 0; i < this.properties.length; i++) {
			if(properties[i].getRentAmount() > highestRent) {
				highestRent = properties[i].getRentAmount();
				highestRentProperty = properties[i];
			}
		}
		return highestRentProperty;
	}
	
	public double getMgmFeePer() {
		return mgmFee;
	}
	
	public String getName() {
		return name;
	}
	
	public Plot getPlot() {
		return this.plot;
	}
	
	public Property[] getProperties() {
		return this.properties;
	}
	
	public int getPropertiesCount() {
	//	return properties.length;
	return this.numberOfProperties;
	}
	
	public String getTaxID() {
		return taxID;
	}
	
	public double getTotalRent() {
		double totalRent = 0.0;
		for(int i = 0; i < properties.length; i++) {
			totalRent += properties[i].getRentAmount();
		}
		return totalRent;
	}
	
	public boolean isManagementFeeValid() {
		if(mgmFee >= 0 && mgmFee <= 100) {
			return true;
		}
		return false;
	}
	
	public boolean isPropertiesFull() {
		if(properties.length == 5) {
			return true;
		}
		return false;
	}
	
	public void removeLastProperty() {
		int index = numberOfProperties - 1;
		properties[index] = null;
	}
	
	public String toString() {
		String result = new String("List of the properties for " + name + ", " + "taxID: " + taxID + "\n");
		result += "_________________________\n";
		for(int i = 0; i < properties.length; i++) {
			if(properties[i] != null) {
			result += properties[i].getPropertyName() + "," + properties[i].getCity() + "," +  properties[i].getOwner()+ "," + properties[i].getRentAmount() + "\n";
			}
		}
		result += "_________________________\n";
		double totalMgmFee = 0.0;
		for(int i = 0; i < numberOfProperties; i++) {
			totalMgmFee += mgmFee;
		}
		result += "total management fee: " + totalMgmFee + "\n";
		return result;
	}
	

}
