package properties;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class ManagementCompanyGFATest {
	properties.Property sampleProperty;
	ManagementCompany mangementCo ; 
	
	@BeforeEach
	public void setUp() throws Exception {
		mangementCo= new ManagementCompany("Railey", "555555555",6);
	}

	@AfterEach
	public void tearDown() throws Exception {
		mangementCo=null;
	}

	@Test
	public void testAddProperty() {
		ManagementCompany managementCo2 = new ManagementCompany();
		sampleProperty = new properties.Property ("Sunsational", "Beckman", 2613, "BillyBob Wilson",2,5,2,2);		 
		assertEquals(managementCo2.addProperty(sampleProperty),1);	//property has been successfully added to index 0
	}
	
	@Test
	public void testGetPropertiesCount() {
		ManagementCompany managementCo2 = new ManagementCompany();
		sampleProperty = new properties.Property ("Sunsational", "Beckman", 2613, "BillyBob Wilson",2,5,2,2);		 
		assertEquals(managementCo2.addProperty(sampleProperty),1);	
		assertEquals(managementCo2.getPropertiesCount(), 1);
	}

	@Test
	public void testToString() {
		sampleProperty = new properties.Property ("Sunsational", "Beckman", 2613.0, "BillyBob Wilson",2,5,2,2);
		assertEquals(mangementCo.addProperty(sampleProperty), 1);	//property has been successfully added to index 0
		String expectedString = "List of the properties for Railey, taxID: 555555555\n"
				+ "_________________________\n"
				+ "Sunsational,Beckman,BillyBob Wilson,2613.0\n"
				+ "_________________________\n"
				
				+ "total management fee: " + 6.0 + "\n";
		System.out.println(mangementCo.toString());
		System.out.println(expectedString);
		assertEquals(expectedString, mangementCo.toString());
		
		
//		String result = "List of the properties for " + name + ", " + "taxID: " + taxID + "\n";
//		System.out.println("_________________________");
//		for(int i = 0; i < properties.length; i++) {
//			result += properties[i].toString() + "\n";
//		}
//		System.out.println("_________________________");
//		double totalMgmFee = 0.0;
//		for(int i = 0; i < properties.length; i++) {
//			totalMgmFee += mgmFee;
//		}
//		System.out.println("total management fee: " + totalMgmFee);
//		return result;
				
	}

}
