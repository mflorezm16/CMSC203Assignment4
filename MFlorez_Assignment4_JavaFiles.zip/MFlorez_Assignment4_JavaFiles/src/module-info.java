/**
 * 
 */
/**
 * 
 */
module CMSC203Assignment4 {
	requires javafx.base;
	requires java.desktop;
	requires javafx.controls;
	requires junit;
	requires org.junit.jupiter.api;
}